// synergy.ts
import type { Stats } from "../types/game";

export const SYNERGY_CONFIG = [
    { label: 'CRIT RATE', bonus: 0.5, divisor: 100, statKey: 'luk' as keyof Stats, targetKey: 'critRate' as keyof Stats, isPercent: true },
    { label: 'CRIT DMG', bonus: 0.5, divisor: 50, statKey: 'luk' as keyof Stats, targetKey: 'critDmg' as keyof Stats },
];

export const calculateSynergyStats = (baseStats: Stats, equippedSkill?: any): Stats => {
    const stats = { ...baseStats };

    SYNERGY_CONFIG.forEach(cfg => {
        const value = baseStats[cfg.statKey] || 0;
        const target = cfg.targetKey;
        stats[target] = (stats[target] || 0) + Math.floor((value / cfg.divisor) * cfg.bonus);
    });

    stats.skillPower = equippedSkill?.effectPower || 0;

    return stats;
};

export const getSynergyInfo = () => SYNERGY_CONFIG.map(c => ({
    label: c.label,
    bonus: `+${c.bonus}${c.isPercent ? '%' : ''}`,
    stat: `${c.divisor} ${(c.statKey as string).toUpperCase()}`
}));