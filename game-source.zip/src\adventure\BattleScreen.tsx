import { useState, useMemo, useEffect } from 'react';
import { getEffectiveStats } from '../utils/combat';
import { useBattle } from '../hooks/useBattle';
import type { Stats, Boss, Player } from '../types/game';
import { RewardModal } from '../components/Modals/RewardModal';
import { useGameStore } from '../store/gameStore'; // ดึง store มาใช้

interface BattleScreenProps {
    player: Player;
    selectedBoss: Boss | null;
    finalStats: Stats;
    onBack: () => void;
    onGameOver: () => void;
}

export const BattleScreen = ({ player, selectedBoss, finalStats, onBack, onGameOver }: BattleScreenProps) => {
    const [showBossStats, setShowBossStats] = useState(false);

    const [showRewardModal, setShowRewardModal] = useState(false);
    const [receivedRewards, setReceivedRewards] = useState<any[]>([]);

    const [isVictory, setIsVictory] = useState(false);

    if (!selectedBoss) {
        return (
            <div className="bg-slate-900 p-6 rounded-xl border border-slate-700 max-w-2xl mx-auto text-white text-center">
                <p className="text-red-400 mb-4">No boss selected!</p>
                <button onClick={onBack} className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-white font-bold">
                    ← Back
                </button>
            </div>
        );
    }


    const bossEffectiveStats = useMemo(
        () => getEffectiveStats(selectedBoss.stats),
        [selectedBoss]
    );

    const { battleLog, isFighting, setIsFighting, bossHp, playerHp, resetBattle } = useBattle(
        player,
        selectedBoss,
        finalStats,
        bossEffectiveStats,
        onGameOver
    );

    useEffect(() => {
        if (bossHp <= 0 && !isVictory) {
            setIsVictory(true);
            setIsFighting(false);

            // เรียกจาก Store ที่นี่ที่เดียว
            const rewards = useGameStore.getState().handleBossDefeated(selectedBoss);
            setReceivedRewards(rewards);
            setShowRewardModal(true);
        }
    }, [bossHp, isVictory, selectedBoss]);

    // 🟢 สุ่ม Background 1 ครั้งตอนเปิดหน้าจอนี้ขึ้นมา
    const [currentBg] = useState(() => {
        const backgrounds = [
            '/Icons/Backgrounds/01_stone_corridor.png',
            '/Icons/Backgrounds/02_throne_room.png',
            '/Icons/Backgrounds/03_treasure_room.png',
            '/Icons/Backgrounds/04_prison_cells.png',
            '/Icons/Backgrounds/05_ancient_library.png',
            '/Icons/Backgrounds/06_ritual_chamber.png',
            '/Icons/Backgrounds/07_crystal_cave.png',
            '/Icons/Backgrounds/08_lava_chamber.png',
            '/Icons/Backgrounds/09_ancient_crypt.png',
            '/Icons/Backgrounds/10_boss_room.png',
        ];
        return backgrounds[Math.floor(Math.random() * backgrounds.length)];
    });

    return (
        <div
            className="relative p-6 rounded-xl border border-slate-700 max-w-5xl mx-auto text-white overflow-hidden bg-cover bg-center"
            style={{ backgroundImage: `url(${currentBg})` }}
        >
            {/* Overlay สีดำจางๆ */}
            <div className="absolute inset-0 bg-slate-950/30 bg-linear-to-b from-slate-950/20 via-slate-950/40 to-slate-950/70"></div>

            {/* Content Wrapper */}
            <div className="relative z-10">
                {/* Header: ปุ่ม Back อยู่บนสุด */}
                <div className="flex items-center justify-between mb-4">
                    <button onClick={onBack} className="text-slate-400 hover:text-white font-medium transition">
                        ← Back
                    </button>
                </div>

                {/* 🟢 Grid 2 คอลัมน์ (ซ้าย: Status & Controls, ขวา: Battle Log) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">

                    {/* ===================== กรอบซ้าย: BOSS & PLAYER STATUS ===================== */}
                    <div className="flex flex-col justify-between bg-black/10 hover:bg-black/20 p-5 rounded-xl border border-white/10 backdrop-blur-md transition shadow-lg">                        <div>
                        {/* Boss Avatar & Info */}
                        <div className="flex flex-col items-center mb-4">
                            <div className="relative group">
                                <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-cyan-500 rounded-full blur opacity-25 group-hover:opacity-75 transition duration-500"></div>
                                <img
                                    src={selectedBoss.imagePath}
                                    alt={selectedBoss.name}
                                    className="relative w-28 h-28 rounded-full border-4 border-slate-800 bg-slate-950 object-cover shadow-2xl"
                                    onError={(e) => (e.currentTarget.src = '/Icons/Monsters/default.png')}
                                />
                            </div>
                            <h2 className="text-2xl text-white font-bold mt-2 drop-shadow-lg">{selectedBoss.name}</h2>
                            <span className="mt-1 px-3 py-0.5 bg-amber-950/60 border border-amber-700/50 rounded-full text-xs text-amber-400 font-bold uppercase tracking-widest shadow-inner">
                                Level {selectedBoss.level}
                            </span>
                        </div>

                        {/* Toggle Boss Stats */}
                        <div className="flex justify-end mb-2">
                            <button
                                onClick={() => setShowBossStats(!showBossStats)}
                                className="text-xs text-blue-400 hover:text-blue-300 font-medium"
                            >
                                {showBossStats ? 'Hide Boss Stats' : 'Show Boss Stats'}
                            </button>
                        </div>

                        {/* Boss Stats Details */}
                        {showBossStats && (
                            <div className="space-y-3 mb-4 p-3 bg-slate-900/90 rounded border border-slate-800 text-xs animate-fadeIn">
                                <div>
                                    <p className="text-blue-400 font-bold border-b border-slate-800 pb-1 mb-1">Combat Power</p>
                                    <div className="grid grid-cols-2 gap-1.5 text-slate-400">
                                        <p>ATK: <span className="text-white">{bossEffectiveStats.atk.toLocaleString()}</span></p>
                                        <p>DEF: <span className="text-white">{bossEffectiveStats.def.toLocaleString()}</span></p>
                                        <p>RES: <span className="text-white">{bossEffectiveStats.res.toLocaleString()}</span></p>
                                        <p>MRES: <span className="text-white">{(bossEffectiveStats.mRes || 0).toLocaleString()}</span></p>
                                        <p>FLEE: <span className="text-white">{bossEffectiveStats.flee.toLocaleString()}</span></p>
                                        <p>HIT: <span className="text-white">{bossEffectiveStats.hit.toLocaleString()}</span></p>
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-2 border-t border-slate-800/80 pt-2">
                                    <div>
                                        <p className="text-red-400 font-bold mb-1">Critical</p>
                                        <p className="text-slate-400">Rate: <span className="text-white">{selectedBoss.stats.critRate}%</span></p>
                                        <p className="text-slate-400">Dmg: <span className="text-white">{selectedBoss.stats.critDmg}%</span></p>
                                    </div>
                                    <div>
                                        <p className="text-yellow-400 font-bold mb-1">Attributes</p>
                                        <p className="text-slate-400">ธาตุ: <span className="text-white">{selectedBoss.element}</span></p>
                                        <p className="text-slate-400">เผ่า: <span className="text-white">{selectedBoss.race}</span></p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Boss HP Bar */}
                        <div className="mb-3">
                            <div className="flex justify-between text-xs text-slate-400 mb-1">
                                <span className="font-semibold text-red-400">Boss HP :</span>
                                <span>{(bossHp ?? 0).toLocaleString()} / {bossEffectiveStats.maxHp.toLocaleString()}</span>
                            </div>
                            <div className="w-full bg-slate-800 h-3.5 rounded-full overflow-hidden border border-slate-700 shadow-inner">
                                <div
                                    className="bg-gradient-to-r from-red-700 to-red-500 h-full transition-all duration-300"
                                    style={{ width: `${Math.max(0, (bossHp / bossEffectiveStats.maxHp) * 100)}%` }}
                                ></div>
                            </div>
                        </div>

                        {/* Player HP Bar */}
                        <div className="mb-4">
                            <div className="flex justify-between text-xs text-slate-400 mb-1">
                                <span className="font-semibold text-emerald-400">Player HP :</span>
                                <span>{playerHp.toLocaleString()} / {finalStats.maxHp.toLocaleString()}</span>
                            </div>
                            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden border border-slate-700 shadow-inner">
                                <div
                                    className="bg-emerald-500 h-full transition-all duration-300"
                                    style={{ width: `${Math.max(0, (playerHp / finalStats.maxHp) * 100)}%` }}
                                ></div>
                            </div>
                        </div>
                    </div>

                        {/* Action Buttons */}
                        <div className="flex gap-2 mt-4 pt-4 border-t border-slate-800/80">
                            <button
                                onClick={() => {
                                    if (bossHp <= 0) {
                                        resetBattle();
                                        setIsVictory(false);
                                    } else {
                                        setIsFighting(!isFighting);
                                    }
                                }}
                                disabled={playerHp <= 0}
                                className={`flex-grow py-3 rounded-lg font-bold text-sm transition-all shadow-md ${bossHp <= 0
                                    ? 'bg-emerald-600 hover:bg-emerald-500 animate-pulse'
                                    : isFighting
                                        ? 'bg-red-600 hover:bg-red-500'
                                        : 'bg-emerald-600 hover:bg-emerald-500'
                                    } disabled:bg-slate-800 disabled:text-slate-500`}
                            >
                                {bossHp <= 0
                                    ? 'Fight Again'
                                    : playerHp <= 0
                                        ? 'Defeated...'
                                        : isFighting
                                            ? 'Stop Fighting'
                                            : 'Start Battle'}
                            </button>

                            <button
                                onClick={onBack}
                                className="px-4 py-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-white text-sm font-bold transition"
                            >
                                Lobby
                            </button>
                        </div>
                    </div>

                    {/* ===================== กรอบขวา: BATTLE LOG ===================== */}
                    <div className="flex flex-col h-full bg-slate-950/80 p-4 rounded-xl border border-slate-800 backdrop-blur-sm min-h-[380px] max-h-[520px]">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 pb-2 border-b border-slate-800 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                            Battle Log
                        </h3>

                        {/* Log Container (ขยายเต็มพื้นที่ฝั่งขวา) */}
                        <div className="flex-grow overflow-y-auto pr-1 text-xs space-y-1.5 scrollbar-thin scrollbar-thumb-slate-700">
                            {battleLog.length === 0 ? (
                                <div className="h-full flex items-center justify-center text-slate-600 italic">
                                    Click "Start Battle" to begin combat...
                                </div>
                            ) : (
                                battleLog.map((log, i) => (
                                    <div
                                        key={i}
                                        className={`p-1.5 rounded leading-relaxed ${log.type === 'player'
                                            ? 'text-emerald-300 bg-emerald-950/20 border-l-2 border-emerald-500'
                                            : 'text-red-300 bg-red-950/20 border-l-2 border-red-500'
                                            }`}
                                    >
                                        {log.text}
                                    </div>
                                ))
                            )}

                        </div>
                    </div>

                </div>
            </div>

            {/* Modal แสดงของรางวัล */}
            {showRewardModal && receivedRewards.length > 0 && (
                <RewardModal
                    rewards={receivedRewards}
                    onClose={() => setShowRewardModal(false)}
                />
            )}
        </div>
    );
}
